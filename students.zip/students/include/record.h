#ifndef RECORD_H
#define RECORD_H
#include <string>

class Record{
public:
	void setRecord(int num, std::string str, int x, int y, int z);
	void printRecord() const;
private:
	int no;
	std::string name;
	int score1;
	int score2;
	int score3;
	float average;

};

#endif

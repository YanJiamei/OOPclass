#include <iostream>
#include "record.h"

void Record::setRecord(int num, std::string str, int x, int y, int z){
	score1 = x;
	score2 = y;
	score3 = z;
	no	   = num;
	name   = str;
	average= float( x + y + z ) / 3;
}

void Record::printRecord() const{

	std::cout << no << "\t" << name << "\t" << score1 << "\t"
				<< score2 << "\t" << score3 << "\t" << average << std::endl;
}
